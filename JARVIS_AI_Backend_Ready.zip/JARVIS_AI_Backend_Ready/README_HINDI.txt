JARVIS AI BACKEND — READY PACKAGE

यह पैकेज Backend server files तैयार रखता है। यह अपने-आप GitHub/Render पर upload या deploy नहीं करता, क्योंकि आपके निजी account में login/permission मेरे पास नहीं है।

फाइलें:
- server.js: Gemini AI से बात करने वाला backend
- package.json: आवश्यक Node packages
- .env.example: environment variables के नाम (इसमें असली key नहीं है)

ज़रूरी सुरक्षा:
1. असली Gemini API key को GitHub पर कभी न डालें।
2. Hosting dashboard के Environment Variables/Secrets में GEMINI_API_KEY जोड़ें।
3. JARVIS_ACCESS_TOKEN के लिए लंबा, random token बनाएँ और उसी को hosting secret में रखें।
4. ऐप के Web component में URL /chat और header Authorization: Bearer YOUR_TOKEN सेट करना होगा। ध्यान दें: ऐप में रखा token APK से निकाला जा सकता है, इसलिए यह पूर्ण सुरक्षा नहीं है; rate limit भी है। यदि ऐप सार्वजनिक करना है तो बेहतर user authentication/quotas जोड़ें।
5. API key और token को चैट, स्क्रीनशॉट या सार्वजनिक पोस्ट में साझा न करें।
6. Free-tier की सीमाएँ और डेटा-नीति बदल सकती हैं; निजी/संवेदनशील जानकारी AI को न भेजें।

Hosting पर सामान्य सेटिंग:
- Runtime: Node.js
- Build command: npm install
- Start command: npm start
- Environment variables: GEMINI_API_KEY, JARVIS_ACCESS_TOKEN, (optional) GEMINI_MODEL
- Deploy के बाद /health खोलकर {"ok":true} जाँचें।

यह पैकेज .aia या APK नहीं है। MIT App Inventor में Web component और blocks जोड़ना अलग चरण है।
