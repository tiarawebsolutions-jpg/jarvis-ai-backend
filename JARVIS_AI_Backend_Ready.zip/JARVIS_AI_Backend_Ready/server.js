import express from "express";
import rateLimit from "express-rate-limit";

const app = express();
app.set("trust proxy", 1);
app.use(express.json({ limit: "20kb" }));

const PORT = process.env.PORT || 3000;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const JARVIS_ACCESS_TOKEN = process.env.JARVIS_ACCESS_TOKEN;
const MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";

app.get("/", (_req, res) => res.json({
  service: "JARVIS AI Backend",
  status: "online",
  note: "Use POST /chat for AI replies."
}));

app.get("/health", (_req, res) => res.json({ ok: true }));

app.use("/chat", rateLimit({
  windowMs: 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "बहुत जल्दी-जल्दी अनुरोध आए हैं। एक मिनट बाद फिर कोशिश करें।" }
}));

app.post("/chat", async (req, res) => {
  try {
    if (!GEMINI_API_KEY || !JARVIS_ACCESS_TOKEN) {
      return res.status(503).json({ error: "Server setup incomplete. Admin must set environment variables." });
    }

    const auth = req.get("authorization") || "";
    if (auth !== `Bearer ${JARVIS_ACCESS_TOKEN}`) {
      return res.status(401).json({ error: "Unauthorized request." });
    }

    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "message is required." });
    if (message.length > 4000) return res.status(413).json({ error: "Message too long (max 4000 characters)." });

    const history = Array.isArray(req.body?.history) ? req.body.history.slice(-8) : [];
    const contents = [];
    for (const item of history) {
      if (!item || !["user", "model"].includes(item.role) || typeof item.text !== "string") continue;
      contents.push({ role: item.role, parts: [{ text: item.text.slice(0, 2000) }] });
    }
    contents.push({ role: "user", parts: [{ text: message }] });

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: "You are JARVIS, a helpful voice assistant. Reply naturally in Hindi when the user speaks Hindi, and otherwise use the user's language. Be concise and safe. Never claim to have performed phone actions. Never instruct the app to automatically call, text, pay, or change device settings; those actions require explicit user confirmation in the app." }]
          },
          contents,
          generationConfig: { temperature: 0.7, maxOutputTokens: 700 }
        })
      }
    );

    const data = await response.json();
    if (!response.ok) {
      console.error("Gemini API error status:", response.status);
      return res.status(502).json({ error: "AI service error. Check the server logs and API quota." });
    }

    const answer = data?.candidates?.[0]?.content?.parts
      ?.map(part => part.text || "").join("").trim();

    if (!answer) return res.status(502).json({ error: "AI returned an empty response." });
    return res.json({ answer });
  } catch (err) {
    console.error("Backend request failed:", err?.message || "unknown error");
    return res.status(500).json({ error: "Server error. Please try again." });
  }
});

app.listen(PORT, () => console.log(`JARVIS backend listening on ${PORT}`));
