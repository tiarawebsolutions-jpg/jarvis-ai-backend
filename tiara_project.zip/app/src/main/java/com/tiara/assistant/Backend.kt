package com.tiara.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Backend {
    private const val CHAT_URL = "https://jarvis-ai-backend-stxe.onrender.com/chat"

    fun chat(ctx: Context, message: String, callback: (String) -> Unit) {
        val token = ctx.getSharedPreferences("tiara", Context.MODE_PRIVATE).getString("token", "") ?: ""
        Thread {
            val answer: String = try {
                val c = URL(CHAT_URL).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 60000
                c.readTimeout = 90000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer $token")

                val history = JSONArray()
                    .put(
                        JSONObject()
                            .put("role", "user")
                            .put(
                                "content",
                                "आज से तुम्हारा नाम तियारा (Tiara) है, तुम एक महिला आवाज़ वाली असिस्टेंट हो। खुद को कभी JARVIS मत कहना। छोटे जवाब देना।"
                            )
                    )
                    .put(
                        JSONObject()
                            .put("role", "assistant")
                            .put("content", "ठीक है, मैं तियारा हूँ। बताइए, मैं आपकी क्या मदद करूँ?")
                    )
                val body = JSONObject().put("message", message).put("history", history).toString()
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val text = stream.bufferedReader().use { it.readText() }
                if (code == 200) JSONObject(text).optString("answer", "जवाब नहीं मिला")
                else "AI से जवाब नहीं मिला, कोड $code"
            } catch (e: Exception) {
                "इंटरनेट या सर्वर में दिक्कत है"
            }
            Handler(Looper.getMainLooper()).post { callback(answer) }
        }.start()
    }
}
