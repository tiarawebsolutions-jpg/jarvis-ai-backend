package com.tiara.assistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.MediaStore

object CommandRouter {

    private val main = Handler(Looper.getMainLooper())

    private val aliases = listOf(
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वाट्सऐप" to "whatsapp",
        "यूट्यूब" to "youtube", "फोनपे" to "phonepe", "फोन पे" to "phonepe",
        "गूगल पे" to "google pay", "जीपे" to "google pay", "पेटीएम" to "paytm",
        "क्रोम" to "chrome", "जीमेल" to "gmail", "मैप्स" to "maps", "गूगल मैप" to "maps",
        "इंस्टाग्राम" to "instagram", "फेसबुक" to "facebook", "टेलीग्राम" to "telegram",
        "सेटिंग्स" to "settings", "सेटिंग" to "settings", "गैलरी" to "gallery",
        "फोटोज" to "photos", "कैलकुलेटर" to "calculator", "घड़ी" to "clock",
        "क्लॉक" to "clock", "कैमरा" to "camera", "संपर्क" to "contacts", "कॉन्टैक्ट" to "contacts"
    )

    private val stopWords = setOf(
        "कॉल", "call", "करो", "कर", "दो", "लगाओ", "लगा", "फोन", "फ़ोन", "को", "तियारा", "tiara",
        "डायल", "dial", "मैसेज", "message", "sms", "एसएमएस", "भेजो", "भेज", "whatsapp",
        "व्हाट्सएप", "पर", "कि", "that", "बोलो", "लिखो", "send", "text", "से", "एक"
    )

    private fun norm(s: String): String {
        val dev = "०१२३४५६७८९"
        val sb = StringBuilder()
        for (c in s.lowercase()) {
            val i = dev.indexOf(c)
            sb.append(if (i >= 0) ('0' + i) else c)
        }
        return sb.toString().replace(Regex("(?<=\\d)\\s+(?=\\d)"), "")
    }

    private fun digits(t: String): String = Regex("\\d+").find(t)?.value ?: ""

    private fun cleanName(t: String): String =
        t.split(" ").filter { it.isNotBlank() && it !in stopWords }.joinToString(" ").trim()

    private fun after(raw: String, keys: List<String>): String? {
        val low = raw.lowercase()
        var best = -1
        var bestKey = ""
        for (k in keys) {
            val i = low.indexOf(k)
            if (i >= 0 && (best < 0 || i < best)) {
                best = i
                bestKey = k
            }
        }
        if (best < 0) return null
        return raw.substring(best + bestKey.length).trim()
    }

    fun startNew(ctx: Context, intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val c: Context = TiaraAccessibilityService.instance ?: ctx
        try {
            c.startActivity(intent)
        } catch (e: Exception) {
        }
    }

    fun handle(ctx: Context, raw: String, say: (String) -> Unit) {
        val t = norm(raw).trim()
        val acc = TiaraAccessibilityService.instance

        fun has(vararg k: String): Boolean = k.any { t.contains(it) }

        fun global(action: Int, ok: String) {
            if (acc == null) say("पहले Accessibility चालू कीजिए")
            else {
                acc.performGlobalAction(action)
                say(ok)
            }
        }

        when {
            has("अनलॉक", "unlock") ->
                say("माफ़ कीजिए, फोन अनलॉक करना Android किसी ऐप को नहीं करने देता। आप पिन या फिंगरप्रिंट खुद डालिए।")

            has("पावर ऑफ", "power off", "पावर मेन्यू", "स्विच ऑफ", "switch off") ->
                global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG, "पावर मेन्यू खोल दिया")

            has("लॉक", "lock", "स्क्रीन बंद", "screen off", "फोन बंद", "फ़ोन बंद") && !has("क्लॉक", "clock", "block") ->
                if (Build.VERSION.SDK_INT >= 28)
                    global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "फोन लॉक कर रही हूँ")
                else say("यह फोन लॉक कमांड सपोर्ट नहीं करता")

            has("होम", "home") -> global(AccessibilityService.GLOBAL_ACTION_HOME, "ठीक है")
            has("पीछे", "वापस", "back", "बैक") -> global(AccessibilityService.GLOBAL_ACTION_BACK, "ठीक है")
            has("रीसेंट", "recent") -> global(AccessibilityService.GLOBAL_ACTION_RECENTS, "ठीक है")
            has("नोटिफिकेशन", "notification") ->
                global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "ठीक है")

            has("स्क्रॉल", "scroll") -> {
                if (acc == null) say("पहले Accessibility चालू कीजिए")
                else {
                    val up = has("ऊपर", " up")
                    acc.scroll(!up)
                    say("ठीक है")
                }
            }

            has("टॉर्च", "torch", "flashlight", "फ्लैश") -> torch(ctx, !has("बंद", "off"), say)

            has("आवाज़ बढ़ा", "आवाज बढ़ा", "volume up", "वॉल्यूम बढ़ा", "आवाज़ तेज", "आवाज तेज") -> {
                volume(ctx, true)
                say("ठीक है")
            }
            has("आवाज़ कम", "आवाज कम", "volume down", "वॉल्यूम कम", "आवाज़ धीमी", "आवाज धीमी") -> {
                volume(ctx, false)
                say("ठीक है")
            }

            has("कैमरा", "camera", "selfie", "फोटो लो", "फोटो खींच", "photo lo") -> {
                startNew(ctx, Intent(MediaStore.ACTION_IMAGE_CAPTURE))
                if (has("फोटो लो", "फोटो खींच", "photo lo") && acc != null) {
                    main.postDelayed({
                        acc.clickText(listOf("Shutter", "शटर", "Take photo", "Capture", "फ़ोटो लें"))
                    }, 3000)
                    main.postDelayed({
                        acc.clickText(listOf("Done", "OK", "ठीक है", "Save"))
                    }, 5500)
                }
                say("कैमरा खोल रही हूँ")
            }

            has("पेमेंट", "payment", "पैसे", "रुपये", "रुपए", "rupees", "pay") && digits(t).isNotEmpty() ->
                pay(ctx, t, say)

            has("क्लिक", "click", "टैप", "tap", "दबाओ", "दबाइए") -> {
                if (acc == null) say("पहले Accessibility चालू कीजिए")
                else {
                    val skip = setOf("क्लिक", "click", "टैप", "tap", "दबाओ", "दबाइए", "करो", "पर", "on", "the", "बटन", "button", "को")
                    val target = t.split(" ").filter { it.isNotBlank() && it !in skip }.joinToString(" ")
                    if (acc.clickText(listOf(target))) say("ठीक है")
                    else say("स्क्रीन पर $target नहीं मिला")
                }
            }

            has("लिखो", "टाइप", "type ") && !has("मैसेज", "message") -> {
                if (acc == null) say("पहले Accessibility चालू कीजिए")
                else {
                    val text = after(raw, listOf("लिखो", "टाइप", "type "))
                    if (!text.isNullOrBlank() && acc.typeText(text)) say("लिख दिया")
                    else say("पहले किसी टेक्स्ट बॉक्स पर टैप कीजिए")
                }
            }

            has("whatsapp", "व्हाट्सएप", "वाट्सऐप", "व्हाट्सऐप") && has("मैसेज", "message", "भेज", "बोलो", "लिख") ->
                compose(ctx, t, true, say)

            has("एसएमएस", "sms", "मैसेज", "message") -> compose(ctx, t, false, say)

            has("कॉल", "call", "फोन लगा", "फ़ोन लगा", "डायल", "dial") -> {
                var num = digits(t)
                if (num.length < 6) {
                    val name = cleanName(t)
                    val found = findNumber(ctx, name)
                    if (found == null) {
                        say("$name नाम का कॉन्टैक्ट नहीं मिला")
                        return
                    }
                    num = found
                }
                if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    say("पहले ऐप में कॉल की अनुमति दीजिए")
                } else {
                    startNew(ctx, Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")))
                    say("कॉल कर रही हूँ")
                }
            }

            has("खोल", "open", "चलाओ", "स्टार्ट", "start", "चालू") -> openApp(ctx, t, say)

            else -> Backend.chat(ctx, raw, say)
        }
    }

    private fun torch(ctx: Context, on: Boolean, say: (String) -> Unit) {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                say("इस फोन में फ्लैश नहीं मिला")
                return
            }
            cm.setTorchMode(id, on)
            say(if (on) "टॉर्च चालू" else "टॉर्च बंद")
        } catch (e: Exception) {
            say("टॉर्च नहीं चल पाई")
        }
    }

    private fun volume(ctx: Context, up: Boolean) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val dir = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        for (i in 1..3) am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    private fun findNumber(ctx: Context, name: String): String? {
        if (name.isBlank()) return null
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"),
            null
        ) ?: return null
        c.use {
            if (it.moveToFirst()) return it.getString(0).replace(Regex("[^0-9+]"), "")
        }
        return null
    }

    private fun compose(ctx: Context, t: String, whatsapp: Boolean, say: (String) -> Unit) {
        val seps = listOf(" कि ", " that ", " बोलो ", " लिखो ", " saying ", " ki ")
        var head = t
        var body = ""
        for (s in seps) {
            val i = t.indexOf(s)
            if (i >= 0) {
                head = t.substring(0, i)
                body = t.substring(i + s.length).trim()
                break
            }
        }
        var num = digits(head)
        if (num.length < 6) {
            val name = cleanName(head)
            val found = findNumber(ctx, name)
            if (found == null) {
                say("$name नाम का कॉन्टैक्ट नहीं मिला")
                return
            }
            num = found
        }
        val acc = TiaraAccessibilityService.instance
        if (whatsapp) {
            val intl = if (num.length == 10) "91$num" else num.removePrefix("+")
            startNew(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("whatsapp://send?phone=$intl&text=" + Uri.encode(body))))
            main.postDelayed({ acc?.clickText(listOf("Send", "भेजें")) }, 3500)
        } else {
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num"))
            i.putExtra("sms_body", body)
            startNew(ctx, i)
            main.postDelayed({ acc?.clickText(listOf("Send SMS", "Send", "भेजें")) }, 3000)
        }
        say("मैसेज तैयार कर रही हूँ")
    }

    private fun pay(ctx: Context, t: String, say: (String) -> Unit) {
        val upi = ctx.getSharedPreferences("tiara", Context.MODE_PRIVATE).getString("upi", "") ?: ""
        if (upi.isBlank()) {
            say("पहले ऐप में सामने वाले की UPI ID सेव कीजिए")
            return
        }
        val amt = digits(t)
        startNew(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("upi://pay?pa=$upi&pn=Payee&cu=INR&am=$amt&tn=TIARA")))
        say("$amt रुपये का पेमेंट स्क्रीन खोल रही हूँ। बैंक और UPI पिन आप खुद डालिए")
    }

    private fun openApp(ctx: Context, t: String, say: (String) -> Unit) {
        var q = t
        for ((k, v) in aliases) q = q.replace(k, v)
        q = q.replace(Regex("खोलो|खोल दो|खोल|open|चलाओ|स्टार्ट|start|चालू|करो|ऐप|app"), " ")
            .replace(Regex("\\s+"), " ").trim()
        val pm = ctx.packageManager
        val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(li, 0)
        val hit = apps.firstOrNull {
            val l = it.loadLabel(pm).toString().lowercase()
            l.length >= 3 && q.contains(l)
        } ?: apps.firstOrNull {
            val l = it.loadLabel(pm).toString().lowercase()
            q.split(" ").any { w -> w.length >= 4 && l.contains(w) }
        }
        if (hit == null) {
            say("वह ऐप नहीं मिला")
            return
        }
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
        if (launch == null) {
            say("वह ऐप नहीं खुल पाया")
            return
        }
        startNew(ctx, launch)
        say(hit.loadLabel(pm).toString() + " खोल रही हूँ")
    }
}
