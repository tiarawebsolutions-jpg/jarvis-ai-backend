package com.tiara.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("tiara", Context.MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad * 2, pad, pad)
        col.setBackgroundColor(Color.parseColor("#071426"))
        scroll.addView(col)

        fun label(t: String, size: Float, bold: Boolean): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = size
            v.setTextColor(Color.WHITE)
            if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
            return v
        }

        fun button(t: String, action: () -> Unit): Button {
            val b = Button(this)
            b.text = t
            b.setOnClickListener { action() }
            return b
        }

        fun edit(hint: String, value: String): EditText {
            val e = EditText(this)
            e.hint = hint
            e.setText(value)
            e.setTextColor(Color.WHITE)
            e.setHintTextColor(Color.GRAY)
            return e
        }

        col.addView(label("TIARA", 34f, true))
        col.addView(label("आपकी आवाज़ से पूरा फोन। \"तियारा\" बोलकर कमांड दीजिए।", 14f, false))

        status = label("", 14f, false)
        col.addView(status)

        col.addView(button("1. परमिशन दें (माइक, कॉल, कॉन्टैक्ट, SMS)") {
            val perms = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.SEND_SMS
            )
            if (Build.VERSION.SDK_INT >= 33) perms.add("android.permission.POST_NOTIFICATIONS")
            requestPermissions(perms.toTypedArray(), 1)
        })

        col.addView(button("2. Accessibility चालू करें (TIARA चुनें)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        col.addView(button("3. \"Display over other apps\" की अनुमति दें") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })

        col.addView(button("4. बैटरी: Unrestricted करें") {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })

        val tokenBox = edit("APP_TOKEN (Render वाला)", prefs.getString("token", "") ?: "")
        val upiBox = edit("पेमेंट के लिए UPI ID (name@upi)", prefs.getString("upi", "") ?: "")
        col.addView(tokenBox)
        col.addView(upiBox)

        col.addView(button("5. टोकन और UPI ID सेव करें") {
            prefs.edit()
                .putString("token", tokenBox.text.toString().trim())
                .putString("upi", upiBox.text.toString().trim())
                .apply()
            Toast.makeText(this, "सेव हो गया", Toast.LENGTH_SHORT).show()
        })

        col.addView(button("▶ TIARA शुरू करें (हमेशा सुनेगी)") {
            startForegroundService(Intent(this, ListenService::class.java))
            Toast.makeText(this, "TIARA शुरू", Toast.LENGTH_SHORT).show()
        })

        col.addView(button("⏹ TIARA बंद करें") {
            stopService(Intent(this, ListenService::class.java))
        })

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        val acc = if (TiaraAccessibilityService.instance != null) "चालू ✅" else "बंद ❌"
        val overlay = if (Settings.canDrawOverlays(this)) "दी हुई ✅" else "बाकी ❌"
        status.text = "Accessibility: $acc   |   Display over apps: $overlay"
    }
}
